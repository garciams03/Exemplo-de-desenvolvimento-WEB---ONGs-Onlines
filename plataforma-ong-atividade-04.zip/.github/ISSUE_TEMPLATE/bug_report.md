---
name: Bug report
about: Report a bug
---

**Resumo**
Descreva o bug.

**Passos para reproduzir**
1. ...
2. ...

**Resultado esperado**
**Resultado atual**
**Ambiente**
- Browser/versão:
- Sistema operacional:
