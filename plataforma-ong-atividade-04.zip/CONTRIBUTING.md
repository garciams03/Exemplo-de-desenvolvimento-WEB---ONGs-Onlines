# Contributing

Siga o GitFlow e a convenção de commits semânticos (Conventional Commits).

Branches:
- main
- develop
- feature/<desc>
- release/<version>
- hotfix/<desc>

Commits semânticos:
- feat:, fix:, chore:, docs:, style:, refactor:, perf:, test:, build:

Abra PRs para `develop`. Use o template de PR.

Antes de commitar localmente:
- rodar `npm run lint`
- rodar `npm run build` (opcional para checar)
