# Plataforma ONG — Repositório GitHub Ready

Este repositório contém o scaffold da plataforma ONG com:
- SPA básico, templates, validação e design system (veja pasta `src/` no pacote principal).
- Arquivos de configuração para GitHub: workflows CI, templates de issues/PR, CONTRIBUTING, CODEOWNERS.
- Scripts de build e release (semantic-release) e configuração para minificação e otimização.

Instruções rápidas:
1. Clone o repositório.
2. Instale dependências: `npm ci`
3. Rodar build local: `npm run build`
4. Testar em servidor local: `npm run start`
5. Para releases automáticas, configure o GitHub Actions (já incluído) e permita `GITHUB_TOKEN`.

Veja os arquivos incluídos neste pacote.
