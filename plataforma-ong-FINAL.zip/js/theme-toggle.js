// Simple theme toggle (light, dark, high-contrast)
const THEMES = ['light','dark','high-contrast'];
export function setTheme(theme){
  if(!THEMES.includes(theme)) theme = 'light';
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('site-theme', theme);
}
export function initTheme(){
  const saved = localStorage.getItem('site-theme') || 'light';
  setTheme(saved);
  document.addEventListener('DOMContentLoaded', ()=>{ const btns = document.querySelectorAll('[data-theme-toggle]'); btns.forEach(b=> b.addEventListener('click', ()=> setTheme(b.getAttribute('data-theme')))); });
}
