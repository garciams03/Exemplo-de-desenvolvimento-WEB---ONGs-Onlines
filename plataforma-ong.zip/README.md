# Plataforma ONG - Scaffold

Conteúdo: 3 páginas HTML semânticas (index, projetos, cadastro), CSS responsivo, JS para interatividade e validação, estrutura de pastas e assets.

Estrutura:

plataforma-ong/
├─ index.html
├─ projetos.html
├─ cadastro.html
├─ css/styles.css
├─ js/main.js
├─ js/validation.js
└─ assets/images/

Instruções: abra `index.html` em um browser. Para produção, configure servidor HTTPS e ferramentas de build.
