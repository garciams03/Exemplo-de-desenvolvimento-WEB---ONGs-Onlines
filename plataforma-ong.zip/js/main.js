// Interatividade simples: menu e ano do rodapé
document.addEventListener('DOMContentLoaded',()=>{
  const btn=document.getElementById('menu-toggle');
  const menu=document.getElementById('main-menu');
  if(btn && menu){
    btn.addEventListener('click',()=>{
      const expanded=btn.getAttribute('aria-expanded')==='true';
      btn.setAttribute('aria-expanded', String(!expanded));
      menu.style.display = expanded ? '' : 'block';
    });
  }
  const ano = document.getElementById('ano');
  if(ano) ano.textContent = new Date().getFullYear();
});
