// Máscaras e validação simples (CPF, telefone e CEP)
function maskCPF(value){
  return value
    .replace(/\D/g,'')
    .replace(/(\d{3})(\d)/,'$1.$2')
    .replace(/(\d{3})(\d)/,'$1.$2')
    .replace(/(\d{3})(\d{1,2})$/,'$1-$2')
}
function maskTel(value){
  return value
    .replace(/\D/g,'')
    .replace(/(\d{2})(\d)/,'($1) $2')
    .replace(/(\d{5})(\d)/,'$1-$2')
}
function maskCEP(value){
  return value
    .replace(/\D/g,'')
    .replace(/(\d{5})(\d)/,'$1-$2')
}

document.addEventListener('DOMContentLoaded',()=>{
  const cpf = document.getElementById('cpf');
  const tel = document.getElementById('telefone');
  const cep = document.getElementById('cep');
  if(cpf){
    cpf.addEventListener('input', e=>{ e.target.value = maskCPF(e.target.value); });
  }
  if(tel){
    tel.addEventListener('input', e=>{ e.target.value = maskTel(e.target.value); });
  }
  if(cep){
    cep.addEventListener('input', e=>{ e.target.value = maskCEP(e.target.value); });
  }

  // Validação de formulário com feedback ARIA
  const form = document.getElementById('form-cadastro');
  if(form){
    form.addEventListener('submit', (ev)=>{
      if(!form.checkValidity()){
        ev.preventDefault();
        // foco no primeiro campo inválido
        const firstInvalid = form.querySelector(':invalid');
        if(firstInvalid){ firstInvalid.focus(); }
        alert('Por favor corrija os campos em destaque.');
      }
    });
  }
});
