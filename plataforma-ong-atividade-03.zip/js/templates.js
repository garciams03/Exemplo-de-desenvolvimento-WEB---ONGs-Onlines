export function homeTemplate(){
  return `
  <section class="card">
    <h1>Bem-vindo à ONG Exemplo</h1>
    <p>Plataforma SPA demonstrativa — gerencie projetos, voluntariado e doações.</p>
  </section>
  `;
}

export function projectsTemplate(){
  return `
  <section>
    <h1>Projetos</h1>
    <div class="card">
      <h2>Projeto A — Educação</h2>
      <p>Descrição e indicadores.</p>
    </div>
    <div class="card" style="margin-top:1rem">
      <h2>Projeto B — Saúde</h2>
      <p>Descrição e indicadores.</p>
    </div>
  </section>
  `;
}

export function cadastroTemplate(){
  return `
  <section>
    <h1>Cadastro</h1>
    <form id="form-cadastro" class="card" novalidate>
      <div class="form-group">
        <label for="nome">Nome completo</label>
        <input id="nome" name="nome" type="text" required minlength="3">
        <div class="field-error" data-for="nome"></div>
      </div>

      <div class="form-group">
        <label for="email">E-mail</label>
        <input id="email" name="email" type="email" required>
        <div class="field-error" data-for="email"></div>
      </div>

      <div class="form-group">
        <label for="cpf">CPF</label>
        <input id="cpf" name="cpf" type="text" inputmode="numeric" required>
        <div class="field-error" data-for="cpf"></div>
      </div>

      <div class="form-group">
        <label for="telefone">Telefone</label>
        <input id="telefone" name="telefone" type="tel" inputmode="tel" required>
        <div class="field-error" data-for="telefone"></div>
      </div>

      <div class="form-group">
        <label for="data-nasc">Data de Nascimento</label>
        <input id="data-nasc" name="data-nasc" type="date" required>
        <div class="field-error" data-for="data-nasc"></div>
      </div>

      <div style="display:flex;gap:0.5rem;margin-top:0.75rem">
        <button type="submit" class="btn">Enviar cadastro</button>
        <button type="button" class="btn secondary" id="btn-check">Checar consistência</button>
      </div>
    </form>
  </section>
  `;
}
