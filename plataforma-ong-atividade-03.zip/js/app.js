import { homeTemplate, projectsTemplate, cadastroTemplate } from './templates.js';
import { attachFormChecks, checkFormConsistency } from './formValidator.js';

const routes = { '/': homeTemplate, '/home': homeTemplate, '/projects': projectsTemplate, '/cadastro': cadastroTemplate };
function parseLocation(){ const hash = location.hash || '#/home'; return hash.replace('#',''); }
function showInlineMessage(form, fieldName, message){ const el = form.querySelector(`[data-for="${fieldName}"]`); if(el){ el.textContent = message; }}

function render(){
  const route = parseLocation();
  const viewFn = routes[route] || routes['/home'];
  const app = document.getElementById('app');
  app.innerHTML = viewFn();
  app.focus();
  if(route === '/cadastro'){
    const form = document.getElementById('form-cadastro');
    if(form){
      attachFormChecks(form);
      const btn = document.getElementById('btn-check');
      if(btn){ btn.addEventListener('click', ()=>{
        const res = checkFormConsistency(form);
        // clear
        form.querySelectorAll('[data-for]').forEach(d=> d.textContent='');
        if(res.ok){ showToast('Consistência verificada: tudo ok'); }
        else { res.messages.forEach(m=> showInlineMessage(form, m.field, m.message)); showToast('Encontrados problemas de consistência', 5000); }
      }); }
    }
  }
}
window.addEventListener('hashchange', render); window.addEventListener('load', render);
export function navigateTo(path){ location.hash = '#' + path; }
