import { maskCPF, maskTel } from './validation.js';

export function attachFormChecks(form){
  const cpf = form.querySelector('#cpf'); const tel = form.querySelector('#telefone');
  if(cpf){ cpf.addEventListener('input', e=> e.target.value = maskCPF(e.target.value)); }
  if(tel){ tel.addEventListener('input', e=> e.target.value = maskTel(e.target.value)); }
  form.querySelectorAll('input,select,textarea').forEach(el=>{
    el.addEventListener('blur', ()=>{
      const errEl = form.querySelector(`[data-for="${el.id}"]`);
      if(!el.checkValidity()){ if(errEl) errEl.textContent = el.validationMessage || 'Campo inválido'; el.classList.add('is-invalid'); }
      else { if(errEl) errEl.textContent = ''; el.classList.remove('is-invalid'); el.classList.add('is-valid'); }
    });
  });
  form.addEventListener('submit', (ev)=>{
    ev.preventDefault();
    form.querySelectorAll('[data-for]').forEach(d=> d.textContent='');
    const res = checkFormConsistency(form);
    if(!res.ok){ res.messages.forEach(m=>{ const el = form.querySelector(`[data-for="${m.field}"]`); if(el) el.textContent = m.message; }); showToast('Corrija os campos indicados',4000); const firstInvalid = form.querySelector('.is-invalid'); if(firstInvalid) firstInvalid.focus(); return; }
    showToast('Formulário válido e consistente — enviado (simulação)'); form.reset();
  });
}

export function checkFormConsistency(form){
  const messages = [];
  const val = (id)=> (form.querySelector('#'+id) ? form.querySelector('#'+id).value.trim() : '');
  form.querySelectorAll('input,select,textarea').forEach(el=>{ if(!el.checkValidity()) messages.push({field: el.id || el.name || 'field', message: el.validationMessage || 'Campo inválido'}); });
  const cpf = val('cpf'); if(cpf && !isValidCPF(cpf)) messages.push({field:'cpf', message:'CPF inválido'});
  const dob = val('data-nasc'); if(dob){ const age = calculateAge(dob); if(age < 13) messages.push({field:'data-nasc', message:'Idade mínima de 13 anos'}); }
  const cep = val('cep'); const cidade = val('cidade'); if(cep && !cidade) messages.push({field:'cidade', message:'Preencha a cidade correspondente ao CEP'});
  const tel = val('telefone').replace(/\D/g,''); if(tel && tel.length < 10) messages.push({field:'telefone', message:'Telefone muito curto'});
  return { ok: messages.length === 0, messages };
}
function calculateAge(dobStr){ const dob = new Date(dobStr); if(Number.isNaN(dob.getTime())) return 0; const diff = Date.now() - dob.getTime(); const ageDt = new Date(diff); return Math.abs(ageDt.getUTCFullYear() - 1970); }
function isValidCPF(cpf){ const onlyNums = cpf.replace(/\D/g,''); if(!onlyNums || onlyNums.length !== 11) return false; if(/^([0-9])\1+$/.test(onlyNums)) return false; const nums = onlyNums.split('').map(n=>parseInt(n,10)); let sum=0; for(let i=0;i<9;i++) sum += nums[i]*(10-i); let rev = 11 - (sum % 11); if(rev === 10 || rev === 11) rev = 0; if(rev !== nums[9]) return false; sum=0; for(let i=0;i<10;i++) sum += nums[i]*(11-i); rev = 11 - (sum % 11); if(rev === 10 || rev === 11) rev = 0; if(rev !== nums[10]) return false; return true; }
