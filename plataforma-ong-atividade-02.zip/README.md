# Plataforma ONG - Updated Scaffold

Novas implementações nesta versão:

- Design System com CSS variables (paleta com 8 cores, tipografia com 5 tamanhos, espaçamento modular);
- Grid 12-colunas e helpers (.row, .col-1..col-12);
- Cinco breakpoints responsivos;
- Componentes: cards, badges, alerts, toasts, modal, buttons com estados;
- Navegação com submenu dropdown e menu mobile (hambúrguer);
- Formulários com validação visual (is-valid / is-invalid);

Arquivos incluídos:
- index.html, projetos.html, cadastro.html
- css/styles.css
- js/main.js, js/validation.js
- assets/images/logo.svg (placeholder), assets/images/projeto-1.webp (placeholder)

Abra `index.html` em um navegador para visualizar o protótipo. Substitua imagens placeholders por imagens reais.
