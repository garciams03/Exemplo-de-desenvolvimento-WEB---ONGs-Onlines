// Enhanced interactions: mobile menu toggle, accessible dropdowns, toasts and modal
document.addEventListener('DOMContentLoaded',()=>{
  const mobileToggle = document.getElementById('mobile-toggle');
  const mobileMenu = document.getElementById('mobile-menu');
  if(mobileToggle && mobileMenu){
    mobileToggle.addEventListener('click', ()=>{
      const open = mobileMenu.classList.toggle('open');
      mobileToggle.setAttribute('aria-expanded', String(open));
    });
  }

  // Accessible dropdowns - add aria attributes
  document.querySelectorAll('.menu li').forEach(li=>{
    const submenu = li.querySelector('.submenu');
    if(submenu){
      const button = li.querySelector('a');
      button.setAttribute('aria-haspopup','true');
      button.setAttribute('aria-expanded','false');
      button.addEventListener('click', (e)=>{
        // allow normal navigation if link has href to another page; prevent for #
        if(button.getAttribute('href') === '#'){
          e.preventDefault();
          const expanded = button.getAttribute('aria-expanded') === 'true';
          button.setAttribute('aria-expanded', String(!expanded));
          submenu.style.display = expanded ? 'none' : 'block';
        }
      });
    }
  });

  // Toast example API
  window.showToast = function(message, ttl=3000){
    let container = document.querySelector('.toast-container');
    if(!container){
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }
    const t = document.createElement('div');
    t.className='toast';
    t.textContent = message;
    container.appendChild(t);
    setTimeout(()=>{ t.remove(); }, ttl);
  }

  // Modal API
  document.querySelectorAll('[data-modal-open]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const id = btn.getAttribute('data-modal-open');
      const modalBackdrop = document.getElementById(id);
      if(modalBackdrop) modalBackdrop.classList.add('open');
    });
  });
  document.querySelectorAll('[data-modal-close]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const id = btn.getAttribute('data-modal-close');
      const modalBackdrop = document.getElementById(id);
      if(modalBackdrop) modalBackdrop.classList.remove('open');
    });
  });

  // set year in footer if present
  const ano = document.getElementById('ano');
  if(ano) ano.textContent = new Date().getFullYear();
});
