// Masks and validation with visual states
function maskCPF(value){
  return value.replace(/\D/g,'').replace(/(\d{3})(\d)/,'$1.$2').replace(/(\d{3})(\d)/,'$1.$2').replace(/(\d{3})(\d{1,2})$/,'$1-$2')
}
function maskTel(value){
  return value.replace(/\D/g,'').replace(/(\d{2})(\d)/,'($1) $2').replace(/(\d{5})(\d)/,'$1-$2')
}
function maskCEP(value){
  return value.replace(/\D/g,'').replace(/(\d{5})(\d)/,'$1-$2')
}

document.addEventListener('DOMContentLoaded',()=>{
  const cpf = document.getElementById('cpf');
  const tel = document.getElementById('telefone');
  const cep = document.getElementById('cep');
  if(cpf){ cpf.addEventListener('input', e=>{ e.target.value = maskCPF(e.target.value); }); }
  if(tel){ tel.addEventListener('input', e=>{ e.target.value = maskTel(e.target.value); }); }
  if(cep){ cep.addEventListener('input', e=>{ e.target.value = maskCEP(e.target.value); }); }

  const form = document.getElementById('form-cadastro');
  if(form){
    form.addEventListener('submit', (ev)=>{
      // run native validation then toggle visual classes
      if(!form.checkValidity()){
        ev.preventDefault();
        const invalids = form.querySelectorAll(':invalid');
        invalids.forEach(f=> f.classList.add('is-invalid'));
        const valids = form.querySelectorAll(':valid');
        valids.forEach(f=> f.classList.add('is-valid'));
        const firstInvalid = form.querySelector(':invalid');
        if(firstInvalid) firstInvalid.focus();
        window.showToast('Corrija os campos obrigatórios', 4000);
      } else {
        // simulate success
        ev.preventDefault();
        window.showToast('Cadastro enviado com sucesso!', 3500);
        form.reset();
      }
    });

    // Remove validation classes on input
    form.querySelectorAll('input,select,textarea').forEach(el=>{
      el.addEventListener('input', ()=>{
        el.classList.remove('is-invalid');
        el.classList.remove('is-valid');
      });
    });
  }
});
